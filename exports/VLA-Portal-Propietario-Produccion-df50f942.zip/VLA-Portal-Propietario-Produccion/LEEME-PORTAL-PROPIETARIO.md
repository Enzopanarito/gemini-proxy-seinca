# Portal del Propietario — Villa Los Apamates

Paquete del código fuente activo en producción.

- Entrada pública: `index.html`
- Repositorio: `Enzopanarito/portaldelpropietario`
- Commit activo: `df50f9424a80ed5aa05a4fca1623b0beaf7a1e36`
- Deploy Netlify: `6a71fe6069f9c82aab4e1350`
- Exportado: 2026-08-05

Se incluye el código completo porque el portal comparte funciones, configuración y lógica financiera con el administrador. No se incluyen contraseñas, tokens, claves API ni valores de variables de entorno. Para desplegar en otra cuenta deben configurarse nuevamente las variables privadas del hosting.
