'use strict';

// Motor central del control automático de acceso cómodo al portón.
// Regla: el acceso se decide exclusivamente por deuda anterior vencida,
// nunca por cargos corrientes ni por reportes pendientes sin validar.

const { sendMail } = require('./_mailer');
const { calculateOwnerBalance, money } = require('./_balance_engine_v4');
const { FIELD_NAMES, mergeConfig, validateRules } = require('./_automation_rules');
const { evaluateAccessDecision } = require('./_access_decision_engine');
const { attachOfficialBalances, officialControlQuery } = require('./_official_balances');
const {filterActiveExpenses,currentMonthCaracas}=require('./_expense_lifecycle');
const { mkjLogin, mkjSetMemberStatus } = require('./_mkj_client');

const TABLES = {
  propietarios: 'Propietarios',
  pagos: 'Pagos',
  reportes: 'Reportes de Pago',
  gastos: 'Gastos del Mes',
  config: 'Configuración',
  control: 'ControlVersiones'
};

const TOLERANCE = 0.01;
const ACCESS_MODE_FIELD = 'Modo Control Portón';
const ACCESS_MODE_AUTO = 'Automático';
const ACCESS_MODE_MANUAL = 'Manual';

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body)
  };
}

function nowCaracas() {
  return new Intl.DateTimeFormat('es-VE', {
    timeZone: 'America/Caracas', year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  }).format(new Date());
}

function requiredAccessEnv() {
  const missing = [];
  if (!process.env.AIRTABLE_API_TOKEN) missing.push('AIRTABLE_API_TOKEN');
  if (!process.env.AIRTABLE_BASE_ID) missing.push('AIRTABLE_BASE_ID');
  if (!process.env.MKJ_ADMIN_EMAIL) missing.push('MKJ_ADMIN_EMAIL');
  if (!process.env.MKJ_ADMIN_PASSWORD) missing.push('MKJ_ADMIN_PASSWORD');
  return missing;
}

function airtableBaseUrl(tableName, suffix = '') {
  return `https://api.airtable.com/v0/${process.env.AIRTABLE_BASE_ID}/${encodeURIComponent(tableName)}${suffix}`;
}

async function airtableListAll(tableName, query = '') {
  let records = [];
  let offset = null;
  do {
    const separator = query ? '&' : '?';
    const url = airtableBaseUrl(tableName, `${query || ''}${offset ? `${separator}offset=${encodeURIComponent(offset)}` : ''}`);
    const response = await fetch(url, { headers: { Authorization: `Bearer ${process.env.AIRTABLE_API_TOKEN}` } });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error?.message || data.message || `Error cargando ${tableName}`);
    records = records.concat(data.records || []);
    offset = data.offset;
  } while (offset);
  return records;
}

async function airtableGetRecord(tableName, recordId) {
  const response = await fetch(airtableBaseUrl(tableName, '/' + encodeURIComponent(recordId)), {
    headers: { Authorization: `Bearer ${process.env.AIRTABLE_API_TOKEN}` }
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error?.message || data.message || `Error leyendo ${tableName}`);
  return data;
}

async function airtablePatchRecord(tableName, recordId, fields) {
  const response = await fetch(airtableBaseUrl(tableName, '/' + encodeURIComponent(recordId)), {
    method: 'PATCH',
    headers: { Authorization: `Bearer ${process.env.AIRTABLE_API_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ fields, typecast: true })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error?.message || data.message || `Error actualizando ${tableName}`);
  return data;
}

async function airtableCreateRecord(tableName, fields) {
  const response = await fetch(airtableBaseUrl(tableName), {
    method: 'POST',
    headers: { Authorization: `Bearer ${process.env.AIRTABLE_API_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ records: [{ fields }], typecast: true })
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error?.message || data.message || `Error creando ${tableName}`);
  return (data.records || [])[0] || null;
}

function normalizeAccessMode(value) {
  return String(value || '').trim().toLowerCase() === 'manual' ? ACCESS_MODE_MANUAL : ACCESS_MODE_AUTO;
}

async function getAccessMode() {
  const records = await airtableListAll(TABLES.config);
  const record = records[0] || null;
  const mode = normalizeAccessMode(record && record.fields ? record.fields[ACCESS_MODE_FIELD] : ACCESS_MODE_AUTO);
  return { mode, recordId: record ? record.id : null, record };
}

function hasAutomationConfiguration(record) {
  const fields = record && record.fields ? record.fields : {};
  return Object.values(FIELD_NAMES).some(name => Object.prototype.hasOwnProperty.call(fields, name));
}

async function getAutomationRules(modeInfo = null) {
  const access = modeInfo || await getAccessMode();
  const configured = hasAutomationConfiguration(access.record);
  const rules = mergeConfig(access.record || {});
  return { configured, rules, validation: validateRules(rules), recordId: access.recordId };
}

async function setAccessMode(mode) {
  const normalized = normalizeAccessMode(mode);
  const current = await getAccessMode();
  if (!current.recordId) throw new Error('No existe registro de Configuración para guardar el modo del portón.');
  const updated = await airtablePatchRecord(TABLES.config, current.recordId, { [ACCESS_MODE_FIELD]: normalized });
  return { mode: normalized, record: updated };
}

function ownerLinkIncludes(record, fieldName, ownerId) {
  const links = (record.fields || {})[fieldName] || [];
  return Array.isArray(links) && links.includes(ownerId);
}

function calculateExpiredAccessDebt(owner, pagos, reportes, options = {}) {
  // Solo los pagos definitivos afectan la deuda vencida. Los reportes pendientes
  // se conservan para auditoría, pero nunca cubren deuda ni habilitan el portón.
  const {expenses=[],...balanceOptions}=options||{},balance = calculateOwnerBalance(owner, expenses, pagos || [], balanceOptions);
  const expiredUsd = money(Math.max(0, balance.expiredUsd));
  const expiredBsRef = money(Math.max(0, balance.expiredBsRef));
  const ignoredPendingReportIds = (reportes || [])
    .filter(report => (report.fields || {}).Estado === 'Pendiente')
    .filter(report => ownerLinkIncludes(report, 'Propietario que Reporta', owner.id))
    .map(report => String(report.id || '').trim())
    .filter(Boolean)
    .sort();

  return {
    expiredUsd,
    expiredBsRef,
    expiredTotal: money(expiredUsd + expiredBsRef),
    outstandingUsd: money(Math.max(0,balance.usd)),
    outstandingBsRef: money(Math.max(0,balance.bsRef)),
    outstandingTotal: money(Math.max(0,balance.usd)+Math.max(0,balance.bsRef)),
    hasOutstandingBalance: balance.usd>TOLERANCE||balance.bsRef>TOLERANCE,
    pendingUsd: 0,
    pendingBsRef: 0,
    pendingLegacy: 0,
    pendingTotal: 0,
    ignoredPendingReports: ignoredPendingReportIds.length,
    ignoredPendingReportIds,
    hasExpiredDebt: expiredUsd > TOLERANCE || expiredBsRef > TOLERANCE,
    pendingCoversExpiredDebt: false,
    missingUsd: expiredUsd,
    missingBsRef: expiredBsRef
  };
}

function accessDebtText(calc) {
  const parts = [];
  if (calc.expiredUsd > TOLERANCE) parts.push(`USD $${calc.expiredUsd.toFixed(2)}`);
  if (calc.expiredBsRef > TOLERANCE) parts.push(`Bs ref. $${calc.expiredBsRef.toFixed(2)}`);
  return parts.length ? parts.join(' y ') : 'sin deuda vencida';
}

function escapeHtml(value) {
  return String(value || '').replace(/[&<>"']/g, character => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[character]);
}

function limitationEmailHtml(owner, calc) {
  const fields = owner.fields || {};
  const name = escapeHtml(fields.Propietario || 'propietario(a)');
  const house = escapeHtml(fields.Casa || '');
  return `
  <div style="font-family:Arial,sans-serif;color:#0f172a;line-height:1.55">
    <p>Estimado(a) ${name},</p>
    <p>Reciba un cordial saludo.</p>
    <p>Por medio del presente le informamos que, de acuerdo con nuestros registros administrativos, su inmueble presenta una deuda vencida pendiente con el condominio Villas Los Apamates.</p>
    <p>Por tal motivo, el sistema administrativo ha limitado <b>automáticamente</b> el acceso cómodo al portón eléctrico mediante control, aplicación o sistema automatizado.</p>
    <p>Esta medida no impide el acceso a la urbanización, pero sí restringe el uso del sistema cómodo de apertura hasta tanto sea regularizada la situación administrativa.</p>
    <p>El reporte de un pago queda sujeto a revisión administrativa y, por sí solo, no modifica el estado del portón. El acceso se reevaluará únicamente después de registrar un pago definitivo o una autorización específica, auditada y vigente.</p>
    <p>Le agradecemos ponerse al día lo antes posible o reportar su pago a través del portal para que podamos validar la información y solventar la situación.</p>
    <p style="font-size:13px;color:#475569"><b>Referencia administrativa:</b> Casa ${house}. Deuda vencida registrada: ${escapeHtml(accessDebtText(calc))}.</p>
    <p>Atentamente,</p>
    <p><b>Administración<br>Villas Los Apamates</b></p>
  </div>`;
}

async function sendLimitationEmail(owner, calc) {
  const fields = owner.fields || {};
  const to = fields.Email || fields['MKJ Email'];
  if (!to) return { sent: false, status: 'Sin correo del propietario' };
  return sendMail({
    to,
    subject: 'Notificación automática de limitación de acceso cómodo al portón',
    html: limitationEmailHtml(owner, calc)
  });
}

async function loadAccessContext() {
  const [rawOwners, pagos, reportes,officialRecords,gastos] = await Promise.all([
    airtableListAll(TABLES.propietarios),
    airtableListAll(TABLES.pagos),
    airtableListAll(TABLES.reportes),
    airtableListAll(TABLES.control, officialControlQuery()),
    airtableListAll(TABLES.gastos)
  ]);
  const owners = attachOfficialBalances(rawOwners, officialRecords);
  return { owners, pagos, reportes, officialRecords,gastos:filterActiveExpenses(gastos,currentMonthCaracas()) };
}

async function syncOwnerAccess(ownerId, options = {}, context = null) {
  const missing = requiredAccessEnv();
  if (missing.length) throw new Error('Faltan variables privadas: ' + missing.join(', '));

  const modeInfo = options.modeInfo || await getAccessMode();
  if (modeInfo.mode === ACCESS_MODE_MANUAL && options.ignoreMode !== true) {
    return { ownerId, skipped: true, action: 'manual-mode', mode: ACCESS_MODE_MANUAL, reason: 'Control automático del portón en modo Manual. No se ejecutó sincronización automática.' };
  }

  const ctx = context || await loadAccessContext();
  let owner = (ctx.owners || []).find(item => item.id === ownerId);
  if (!owner) owner = await airtableGetRecord(TABLES.propietarios, ownerId);

  const fields = owner.fields || {};
  const memberId = String(options.mkjUserId || fields['MKJ User ID'] || '').trim();
  const previousStatus = fields['Estado Acceso Portón'] || 'Sin configurar';
  const automationInfo = options.automationInfo || await getAutomationRules(modeInfo);
  const calc = calculateExpiredAccessDebt(owner, ctx.pagos, ctx.reportes, {expenses:ctx.gastos||[],...(options.now?{now:options.now}:{}),dueDay:automationInfo.rules.payment.dueDay,surchargeRate:automationInfo.rules.payment.surchargeRate});
  const runMkj = options.runMkj !== false;

  if (!memberId) {
    return { ownerId, casa: fields.Casa, propietario: fields.Propietario, skipped: true, reason: 'Sin MKJ User ID', mode: modeInfo.mode, calc };
  }

  if (fields['Excepción Acceso'] === true) {
    if (previousStatus === 'Excepción Manual' && options.touchUnchanged !== true) {
      return { ownerId, casa: fields.Casa, propietario: fields.Propietario, action: 'skip-exception', estado: 'Excepción Manual', unchanged: true, mode: modeInfo.mode, calc, owner };
    }
    const patched = await airtablePatchRecord(TABLES.propietarios, owner.id, {
      'Estado Acceso Portón': 'Excepción Manual',
      'Última Sync MKJ': nowCaracas(),
      'Motivo Limitación Acceso': 'Omitido por excepción manual de acceso.'
    });
    return { ownerId, casa: fields.Casa, propietario: fields.Propietario, action: 'skip-exception', estado: 'Excepción Manual', mode: modeInfo.mode, calc, owner: patched };
  }

  let desiredAction = 'enable';
  let desiredStatus = 'Habilitado';
  let reason = 'Sin deuda vencida pendiente. Acceso cómodo habilitado.';
  const temporary = false;

  let decision = null;
  if (automationInfo.configured) {
    decision = evaluateAccessDecision({
      rules: automationInfo.rules,
      balance: { expiredUsd:calc.expiredUsd, expiredBsRef:calc.expiredBsRef },
      currentStatus: previousStatus,
      hasException: fields['Excepción Acceso'] === true,
      hasMemberId: Boolean(memberId),
      dataFresh: options.dataFresh !== false,
      consistent: options.consistent !== false,
      pendingReports: calc.ignoredPendingReports,
      now: options.now || new Date()
    });
    desiredAction = decision.action === 'DISABLE' ? 'disable' : decision.action === 'ENABLE' ? 'enable' : 'none';
    desiredStatus = decision.action === 'NONE' ? previousStatus : decision.desiredStatus;
    reason = options.reason || `${decision.reason} ${calc.hasExpiredDebt ? `Deuda vencida: ${accessDebtText(calc)}.` : ''}`.trim();
  } else if (calc.hasExpiredDebt) {
    desiredAction = 'disable';
    desiredStatus = 'Limitado';
    reason = options.reason || `Limitación automática por deuda vencida pendiente (${accessDebtText(calc)}). Los reportes pendientes no modifican el acceso.`;
  }

  let mkjResult = null;
  const shouldCallMkj = desiredAction !== 'none' && runMkj && (options.forceMkj || previousStatus !== desiredStatus);
  if (shouldCallMkj) mkjResult = await mkjSetMemberStatus(memberId, desiredAction, {
    email: fields['MKJ Email'] || fields.Email || '',
    session: options.mkjSession
  });

  if (runMkj && !shouldCallMkj && previousStatus === desiredStatus && options.touchUnchanged !== true) {
    return {
      ownerId: owner.id,
      casa: fields.Casa,
      propietario: fields.Propietario,
      mkjUserId: memberId,
      previousStatus,
      estado: desiredStatus,
      action: desiredAction,
      temporary,
      unchanged: true,
      mode: modeInfo.mode,
      reason,
      mkjStatus: 'sin-cambio',
      email: null,
      calc,
      decision,
      automation: automationInfo.configured ? { configured:true, validation:automationInfo.validation } : { configured:false, legacyPolicy:true },
      owner
    };
  }

  const patch = {
    'Estado Acceso Portón': desiredStatus,
    'Última Sync MKJ': nowCaracas(),
    'Motivo Limitación Acceso': reason
  };
  if (mkjResult?.recoveredMemberId && mkjResult.resolvedMemberId) patch['MKJ User ID'] = mkjResult.resolvedMemberId;
  const patched = await airtablePatchRecord(TABLES.propietarios, owner.id, patch);

  let email = null;
  if (desiredAction === 'disable' && desiredStatus === 'Limitado' && previousStatus !== 'Limitado' && options.sendEmail !== false) {
    email = await sendLimitationEmail(owner, calc).catch(error => ({ sent: false, status: 'Error correo', detail: error.message }));
  }

  return {
    ownerId: owner.id,
    casa: fields.Casa,
    propietario: fields.Propietario,
    mkjUserId: mkjResult?.resolvedMemberId || memberId,
    mkjUserIdRecovered: mkjResult?.recoveredMemberId === true,
    mkjMembershipVerified: mkjResult?.verifiedMembership === true,
    mkjAlreadyApplied: mkjResult?.idempotent === true,
    previousStatus,
    estado: desiredStatus,
    action: desiredAction,
    temporary,
    mode: modeInfo.mode,
    reason,
    mkjStatus: mkjResult ? mkjResult.status : 'sin-cambio',
    email,
    calc,
    decision,
    automation: automationInfo.configured ? { configured:true, validation:automationInfo.validation } : { configured:false, legacyPolicy:true },
    owner: patched
  };
}

async function autoSyncAll(options = {}) {
  const modeInfo = await getAccessMode();
  const automationInfo = await getAutomationRules(modeInfo);
  if (modeInfo.mode === ACCESS_MODE_MANUAL && options.ignoreMode !== true) {
    return {
      success: true,
      mode: ACCESS_MODE_MANUAL,
      skipped: true,
      total: 0,
      limited: 0,
      enabled: 0,
      errors: 0,
      message: 'Control automático del portón en modo Manual. No se ejecutó sincronización automática.',
      results: []
    };
  }

  const context = await loadAccessContext();
  const results = [];
  for (const owner of context.owners.sort((a, b) => Number((a.fields || {}).Casa || 0) - Number((b.fields || {}).Casa || 0))) {
    try {
      results.push(await syncOwnerAccess(owner.id, { ...options, modeInfo, automationInfo }, context));
    } catch (error) {
      results.push({ ownerId: owner.id, casa: owner.fields?.Casa, propietario: owner.fields?.Propietario, error: error.message });
    }
  }
  const errorCount = results.filter(result => result.error).length;
  return {
    success: errorCount === 0,
    mode: modeInfo.mode,
    total: results.length,
    limited: results.filter(result => result.estado === 'Limitado').length,
    enabled: results.filter(result => result.estado === 'Habilitado').length,
    skipped: results.filter(result => result.skipped || result.action === 'skip-exception').length,
    errors: errorCount,
    results
  };
}

module.exports = {
  json,
  money,
  nowCaracas,
  requiredAccessEnv,
  airtableGetRecord,
  airtableCreateRecord,
  airtablePatchRecord,
  getAccessMode,
  setAccessMode,
  getAutomationRules,
  hasAutomationConfiguration,
  loadAccessContext,
  calculateExpiredAccessDebt,
  syncOwnerAccess,
  autoSyncAll,
  mkjLogin,
  mkjSetMemberStatus,
  TABLES,
  ACCESS_MODE_AUTO,
  ACCESS_MODE_MANUAL
};
