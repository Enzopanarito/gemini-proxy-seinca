'use strict';

const previous=require('./public-data-v2');
const snapshotStore=require('./_public_snapshot_store');
const previewFixture=require('./_public_preview_fixture');

function response(statusCode,payload,headers={}){return{statusCode,headers:{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff',...headers},body:JSON.stringify(payload)}}
function parseBody(result){try{return JSON.parse(result&&result.body||'{}')}catch(_){return{}}}
function cachedResponse(snapshot,state,extra={}){return response(200,snapshot.payload,{'X-Public-Snapshot':state,'X-Airtable-Calls':'0','X-Balance-Engine':'5',...extra})}
function forceEvent(event){return{...event,queryStringParameters:{...(event.queryStringParameters||{}),force:'1'}}}
function sleep(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
async function waitForSnapshot(readSnapshot=snapshotStore.readPublicSnapshot,sleepFn=sleep,env=process.env){for(let attempt=0;attempt<12;attempt+=1){await sleepFn(250);const current=await readSnapshot(env).catch(()=>null);if(current&&current.ok&&current.fresh)return current}return null}

function createHandler(deps={}){
 const previousHandler=deps.previousHandler||previous.handler;
 const isEnabled=deps.enabled||snapshotStore.enabled;
 const eventEnvironment=deps.environmentForEvent||snapshotStore.environmentForEvent;
 const eventHost=deps.requestHost||snapshotStore.requestHost;
 const readSnapshot=deps.readPublicSnapshot||snapshotStore.readPublicSnapshot;
 const writeSnapshot=deps.writePublicSnapshot||snapshotStore.writePublicSnapshot;
 const claimRefresh=deps.claimPublicRefresh||snapshotStore.claimPublicRefresh;
 const releaseRefresh=deps.releasePublicRefresh||snapshotStore.releasePublicRefresh;
 const expectedEtag=deps.snapshotExpectedEtag||snapshotStore.snapshotExpectedEtag;
 const previewEnabled=deps.previewEnabled||previewFixture.enabled;
 const createPreviewPayload=deps.createPreviewPayload||previewFixture.createPayload;
 const previewHeaders=deps.previewHeaders||previewFixture.headers;
 const now=deps.now||(()=>new Date());

 return async function handler(event){
  const host=eventHost(event);
  const snapshotEnv=eventEnvironment(event);

  // Los Deploy Previews, branch deploys y el entorno local nunca consultan la
  // base de producción. Reciben una fotografía ficticia y determinista que
  // permite probar las 15 casas, el desglose y el diseño sin escrituras ni
  // dependencia de credenciales o del esquema incompleto de staging.
  if(previewEnabled(snapshotEnv)){
   return response(200,createPreviewPayload(now()),{
    ...previewHeaders(),
    'X-Public-Snapshot':'PREVIEW_FIXTURE'
   });
  }

  if(!isEnabled(snapshotEnv,snapshotStore.runtimeConfig,host))return previousHandler(event);
  const waitSnapshot=deps.waitForSnapshot||(()=>waitForSnapshot(readSnapshot,deps.sleep||sleep,snapshotEnv));
  let cached=null,blobReadError=null;
  try{cached=await readSnapshot(snapshotEnv)}catch(error){blobReadError=error}
  if(cached&&cached.ok&&cached.fresh)return cachedResponse(cached.snapshot,'HIT');
  const versionRead=blobReadError?undefined:expectedEtag(cached);

  let lease=null;
  if(!blobReadError){try{lease=await claimRefresh(snapshotEnv)}catch(error){blobReadError=error}}
  if(lease&&!lease.ok){
   if(cached&&cached.ok)return cachedResponse(cached.snapshot,'STALE',{'Warning':'110 - "Respuesta pública temporalmente antigua durante revalidación"'});
   const refreshed=await waitSnapshot().catch(()=>null);
   if(refreshed)return cachedResponse(refreshed.snapshot,'WAIT_HIT');
   return response(503,{message:'La fotografía pública se está reconstruyendo. Intente nuevamente en unos segundos.'},{'Retry-After':'3','X-Public-Snapshot':'REFRESH_BUSY'});
  }

  try{
   const fresh=await previousHandler(forceEvent(event)),payload=parseBody(fresh);
   if(fresh.statusCode===200){
    let writeWarning=null;
    if(!blobReadError){try{await writeSnapshot(payload,snapshotEnv,versionRead)}catch(error){writeWarning=`${error.code||'PUBLIC_SNAPSHOT_WRITE'}: ${String(error.message||'').slice(0,240)}`}}
    return response(200,payload,{...(fresh.headers||{}),'Cache-Control':'no-store','X-Public-Snapshot':blobReadError?'BLOB_UNAVAILABLE':writeWarning?'WRITE_WARNING':'REFRESH',...(writeWarning?{'X-Public-Snapshot-Warning':writeWarning}:{})});
   }
   if(cached&&cached.ok)return cachedResponse(cached.snapshot,'STALE_FALLBACK',{'Warning':'111 - "Airtable no disponible; se sirvió la última fotografía validada"'});
   return fresh;
  }catch(error){
   if(cached&&cached.ok)return cachedResponse(cached.snapshot,'STALE_EXCEPTION',{'Warning':'111 - "Error de revalidación; se sirvió la última fotografía validada"'});
   return response(503,{message:'No existe una fotografía pública validada y no fue posible reconstruirla.',detail:String(error.message||'').slice(0,300)},{'X-Public-Snapshot':'ERROR'});
  }finally{if(lease&&lease.ok)await releaseRefresh(lease,snapshotEnv).catch(()=>null)}
 };
}

const handler=createHandler();
exports.handler=handler;
module.exports={handler,createHandler,response,parseBody,forceEvent,cachedResponse,waitForSnapshot};
